
# CIS*6530 — Submission 4: Multi-Class OpCode Classification

**Course:** CIS*6530 – Cyber Threat Intelligence and Adversarial Risk Analysis  
**Instructor:** Dr. Ali Dehghantanha | **TA:** Izabela Savic  
**Project:** Project 1 | **Deadline:** March 24, 2025 by 16:00 EST | **Weight:** 20%

---

## Repository Structure

```
submission4/
├── scripts/
│   ├── preprocess.py       # Hex-byte disassembly → TF-IDF feature matrices
│   ├── classify.py         # SVM / KNN (k=3) / Decision Tree — all 6 experiments
│   └── plot_metrics.py     # Confusion matrices, bar chart, summary heatmap
├── dataset/                # Pre-processed OpCode feature matrices (generated)
│   ├── X_train_1gram.npz   # TF-IDF train matrix, 1-gram  (61 × 427)
│   ├── X_test_1gram.npz    # TF-IDF test  matrix, 1-gram  (16 × 427)
│   ├── X_train_2gram.npz   # TF-IDF train matrix, 2-gram  (61 × 10000)
│   ├── X_test_2gram.npz    # TF-IDF test  matrix, 2-gram  (16 × 10000)
│   ├── y_train.npy         # Integer class labels — train
│   ├── y_test.npy          # Integer class labels — test
│   ├── label_encoder.npy   # APT group name array (index → name)
│   ├── feature_names_1gram.npy
│   ├── feature_names_2gram.npy
│   ├── arch_map.txt        # Per-file x86-32/64 architecture audit log
│   └── preprocessing_summary.txt
├── figures/                # All generated plots and metric reports
│   ├── results_summary.csv
│   ├── metric_bars.png
│   ├── summary_heatmap.png
│   ├── confusion_SVM_1gram.png
│   ├── confusion_SVM_2gram.png
│   ├── confusion_KNN_k3_1gram.png
│   ├── confusion_KNN_k3_2gram.png
│   ├── confusion_DecisionTree_1gram.png
│   ├── confusion_DecisionTree_2gram.png
│   └── report_*.txt        # Per-class classification reports
└── README.md
```

---

## Dataset Summary

| Property | Value |
|---|---|
| Total samples | 77 .opcode files |
| APT groups (classes) | 10 |
| APT1 | 10 samples |
| APT12 | 11 samples |
| APT16 | 7 samples |
| APT17 | 4 samples |
| APT19 | 10 samples |
| APT28 | 10 samples |
| APT29 | 11 samples |
| APT3 | 5 samples |
| Ajax_Security | 4 samples |
| admin@338 | 5 samples |
| Architecture | 55 × x86-32, 22 × x86-64 (auto-detected per file) |
| Train / Test split | 61 / 16 (80/20 stratified, seed=42) |
| 1-gram vocab size | 427 features |
| 2-gram vocab size | 10,000 features |

---

## Dependencies

```bash
pip install capstone scikit-learn numpy scipy pandas matplotlib seaborn
```

Python 3.9 or later required. No internet access needed at runtime.

---

## Execution — 3 Steps

### Step 1: Preprocess

```bash
python scripts/preprocess.py \
    --opcode_dir Raw_Extracted_Files/ \
    --output_dir dataset/ \
    --test_size  0.20 \
    --random_seed 42 \
    --verbose
```

**What it does:**
- Walks `--opcode_dir` for all `*.opcode` files
- Auto-detects x86-32 vs x86-64 architecture per file (REX prefix heuristic)
- Disassembles each hex-byte line using Capstone → mnemonic token
- Infers APT group label from filename: `<APT_GROUP>_<Malware>_<hash>.opcode`
- Performs 80/20 stratified split (seed=42) — preserves class proportions
- Fits TF-IDF on **training data only** (leakage prevention)
- Saves all matrices and metadata to `dataset/`

### Step 2: Classify

```bash
python scripts/classify.py \
    --dataset_dir dataset/ \
    --output_dir  figures/ \
    --random_seed 42
```

**What it does:**
- Trains SVM (RBF, OVR), KNN (k=3, cosine), Decision Tree (Gini) on both gram types
- Reports Accuracy, Precision, Recall, F-measure, Confusion Matrix per experiment
- Saves `figures/results_summary.csv` and per-class reports

### Step 3: Plot

```bash
python scripts/plot_metrics.py \
    --dataset_dir dataset/ \
    --results_dir figures/ \
    --output_dir  figures/
```

**What it does:**
- Generates 6 confusion matrices (raw + normalised), grouped bar chart, summary heatmap
- All figures saved as PNG to `figures/`

---

## Results Summary

| Classifier | N-gram | Accuracy | Precision | Recall | F-measure |
|---|---|---|---|---|---|
| SVM (RBF) | 1-gram | 0.6250 | 0.5104 | 0.6250 | 0.5542 |
| SVM (RBF) | 2-gram | 0.6250 | 0.5833 | 0.6250 | 0.6000 |
| KNN (k=3) | 1-gram | 0.6250 | 0.5625 | 0.6250 | 0.5833 |
| KNN (k=3) | 2-gram | 0.5625 | 0.5000 | 0.5625 | 0.5208 |
| Decision Tree | 1-gram | 0.5625 | 0.5000 | 0.5625 | 0.5250 |
| **Decision Tree** | **2-gram** | **0.7500** | **0.7500** | **0.7500** | **0.7333** |

All metrics are weighted averages. APT28 and APT29 achieve perfect classification
across all six conditions. APT1/APT12 confusion reflects shared Gh0stRAT tooling.

---

## Key Design Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Architecture detection | Per-file auto-detect | Dataset is mixed x86-32 (55) and x86-64 (22). REX bytes misread as DEC in 32-bit mode. |
| Disassembler | Capstone v5.0.7 | Industry-standard; <0.01% skip rate across 77 files |
| Train/test split | 80/20 stratified, seed=42 | Preserves class proportions; fully reproducible |
| TF-IDF fitting | Train only | Prevents vocabulary/IDF leakage into test set |
| TF-IDF sublinear_tf | True | log(1+tf) suppresses ubiquitous opcodes (mov, xor, push) |
| KNN k | 3 | Nearest odd integer to specified k=3.5; avoids tie-breaking |
| KNN distance | Cosine | Length-invariant; appropriate for TF-IDF vectors |
| class_weight | balanced | Compensates for imbalanced APT group counts (4–11 samples) |
| Metric averaging | Weighted | Weights each class by support count |
