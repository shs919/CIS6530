"""
plot_metrics.py
===============
CIS*6530 Submission 4 — Visualisation of Classification Results
Project 1 | Dr. Ali Dehghantanha

USAGE:
    python plot_metrics.py --dataset_dir dataset/ --results_dir figures/

OUTPUT (PNG, saved to --output_dir, defaults to --results_dir):
    confusion_<CLF>_<gram>.png    Raw + row-normalised confusion matrix
    metric_bars.png               Grouped bar chart: all classifiers x grams
    summary_heatmap.png           Compact heatmap of all metrics

DEPENDENCIES:
    pip install matplotlib seaborn numpy pandas
"""

import argparse
import logging
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

CLASSIFIERS = ["SVM", "KNN_k3", "DecisionTree"]
GRAM_TAGS   = ["1gram", "2gram"]
GRAM_LABELS = {"1gram": "1-gram OpCode", "2gram": "2-gram OpCode"}
CLF_LABELS  = {"SVM": "SVM (RBF)", "KNN_k3": "KNN (k=3)", "DecisionTree": "Decision Tree"}
METRIC_COLS = ["Accuracy", "Precision", "Recall", "F-measure"]
COLORS      = ["#0072B2", "#E69F00", "#009E73", "#CC79A7"]   # Okabe & Ito
DPI         = 180


def plot_confusion_matrix(cm, class_names, title, save_path):
    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-12)
    n = len(class_names)
    fig_w = max(14, n * 1.2 + 4)
    fig_h = max(5,  n * 0.55 + 3)

    fig, axes = plt.subplots(1, 2, figsize=(fig_w, fig_h))
    for ax, data, subtitle, fmt in zip(
        axes,
        [cm, cm_norm],
        ["Raw counts", "Row-normalised (recall per class)"],
        ["d", ".2f"],
    ):
        sns.heatmap(
            data, ax=ax, annot=True, fmt=fmt,
            cmap="Blues",
            xticklabels=class_names, yticklabels=class_names,
            linewidths=0.4, linecolor="#cccccc",
            cbar_kws={"shrink": 0.72, "aspect": 28},
            vmin=0, vmax=(None if data is cm else 1.0),
        )
        ax.set_title(subtitle, fontsize=11, pad=8)
        ax.set_xlabel("Predicted label", fontsize=10)
        ax.set_ylabel("True label",      fontsize=10)
        ax.tick_params(axis="x", rotation=45, labelsize=8)
        ax.tick_params(axis="y", rotation=0,  labelsize=8)

    fig.suptitle(title, fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


def plot_metric_bars(df, save_path):
    fig, axes = plt.subplots(1, 2, figsize=(17, 6), sharey=True)
    for ax, gram in zip(axes, ["1-gram", "2-gram"]):
        sub   = df[df["N-gram"] == gram].set_index("Classifier")
        x     = np.arange(len(sub))
        n_met = len(METRIC_COLS)
        width = 0.17

        for i, (metric, color) in enumerate(zip(METRIC_COLS, COLORS)):
            offset = (i - n_met / 2 + 0.5) * width
            bars = ax.bar(
                x + offset, sub[metric], width,
                label=metric, color=color,
                edgecolor="white", linewidth=0.5, zorder=3,
            )
            for bar in bars:
                h = bar.get_height()
                ax.text(
                    bar.get_x() + bar.get_width() / 2, h + 0.007,
                    f"{h:.3f}", ha="center", va="bottom",
                    fontsize=6.5, rotation=90, color="#333333",
                )

        ax.set_title(f"{gram} Features", fontsize=12, fontweight="bold", pad=10)
        ax.set_xticks(x)
        ax.set_xticklabels([CLF_LABELS.get(c, c) for c in sub.index], fontsize=10)
        ax.set_ylim(0, 1.22)
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter("%.2f"))
        ax.set_ylabel("Score", fontsize=10)
        ax.grid(axis="y", linestyle="--", alpha=0.35, zorder=0)
        ax.spines[["top", "right"]].set_visible(False)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, fontsize=10,
               bbox_to_anchor=(0.5, 1.04), frameon=False)
    fig.suptitle(
        "CIS*6530 – Submission 4  |  Classifier Performance: 1-gram vs 2-gram",
        fontsize=12, fontweight="bold", y=1.09,
    )
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


def plot_summary_heatmap(df, save_path):
    df2 = df.copy()
    df2["Condition"] = df2["Classifier"].map(CLF_LABELS) + "\n" + df2["N-gram"]
    pivot = df2.set_index("Condition")[METRIC_COLS]

    fig, ax = plt.subplots(figsize=(9, max(4, len(pivot) * 0.85 + 1.5)))
    sns.heatmap(
        pivot, ax=ax, annot=True, fmt=".4f",
        cmap="YlGnBu", vmin=0, vmax=1,
        linewidths=0.5, linecolor="#cccccc",
        cbar_kws={"label": "Score", "shrink": 0.75},
        annot_kws={"size": 10},
    )
    ax.set_title(
        "Performance Summary — All Classifiers × N-gram Conditions",
        fontsize=12, fontweight="bold", pad=14,
    )
    ax.tick_params(axis="x", rotation=0, labelsize=10)
    ax.tick_params(axis="y", rotation=0, labelsize=9)
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


def main():
    parser = argparse.ArgumentParser(
        description="CIS*6530 Sub4 — generate result figures"
    )
    parser.add_argument("--dataset_dir", required=True)
    parser.add_argument("--results_dir", required=True)
    parser.add_argument("--output_dir",  default=None)
    args = parser.parse_args()

    dataset_dir = Path(args.dataset_dir)
    results_dir = Path(args.results_dir)
    output_dir  = Path(args.output_dir) if args.output_dir else results_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    class_names = list(np.load(str(dataset_dir / "label_encoder.npy"), allow_pickle=True))
    df = pd.read_csv(str(results_dir / "results_summary.csv"))

    log.info("Generating confusion matrices …")
    for clf in CLASSIFIERS:
        for gram_tag in GRAM_TAGS:
            cm_path = results_dir / f"cm_{clf}_{gram_tag}.npy"
            if not cm_path.exists():
                log.warning("Not found, skipping: %s", cm_path.name)
                continue
            cm    = np.load(str(cm_path))
            title = f"{CLF_LABELS.get(clf, clf)}  |  {GRAM_LABELS[gram_tag]}"
            plot_confusion_matrix(
                cm, class_names, title,
                output_dir / f"confusion_{clf}_{gram_tag}.png",
            )

    log.info("Generating bar chart …")
    plot_metric_bars(df, output_dir / "metric_bars.png")

    log.info("Generating heatmap …")
    plot_summary_heatmap(df, output_dir / "summary_heatmap.png")

    log.info("All figures saved to: %s", output_dir)


if __name__ == "__main__":
    main()
