"""
classify.py
===========
CIS*6530 Submission 4 — Multi-Class Malware Classification
Project 1 | Dr. Ali Dehghantanha

Trains SVM, KNN (k=3), and Decision Tree on 1-gram and 2-gram TF-IDF
feature matrices from preprocess.py. Six experiments total.

NOTE on k=3.5:
    The assignment specifies k=3.5, which is not a valid integer.
    We use k=3 — the nearest odd integer. Odd k avoids majority-vote
    ties in multi-class voting. Documented in the technical report.

USAGE:
    python classify.py --dataset_dir dataset/ --output_dir figures/

DEPENDENCIES:
    pip install scikit-learn numpy scipy pandas
"""

import argparse
import logging
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)
DIV = "=" * 66


def get_classifiers(seed: int) -> dict:
    """
    Three required classifiers with documented hyperparameters.

    SVM   RBF kernel; one-vs-rest multi-class; class_weight=balanced to
          compensate for unequal APT group sample counts.
    KNN   k=3 (nearest odd integer to specified k=3.5); cosine distance
          (length-invariant, appropriate for TF-IDF); brute-force search
          required for cosine metric with sparse matrices.
    DTree Full depth; Gini impurity; class_weight=balanced.
          Interpretable: top splits reveal most discriminative opcodes.
    """
    return {
        "SVM": SVC(
            kernel="rbf", C=1.0, gamma="scale",
            decision_function_shape="ovr",
            class_weight="balanced",
            random_state=seed,
        ),
        "KNN_k3": KNeighborsClassifier(
            n_neighbors=3,
            metric="cosine",
            algorithm="brute",
        ),
        "DecisionTree": DecisionTreeClassifier(
            max_depth=None, min_samples_leaf=1,
            criterion="gini", class_weight="balanced",
            random_state=seed,
        ),
    }


def evaluate(y_true, y_pred, class_names) -> dict:
    avg = "weighted"
    return {
        "Accuracy":    accuracy_score(y_true, y_pred),
        "Precision":   precision_score(y_true, y_pred, average=avg, zero_division=0),
        "Recall":      recall_score(y_true, y_pred, average=avg, zero_division=0),
        "F1":          f1_score(y_true, y_pred, average=avg, zero_division=0),
        "ConfMatrix":  confusion_matrix(y_true, y_pred),
        "ClassReport": classification_report(
            y_true, y_pred, target_names=class_names,
            zero_division=0, digits=4),
    }


def print_run(clf_name, gram, m):
    print(f"\n{DIV}")
    print(f"  Classifier : {clf_name}")
    print(f"  N-gram     : {gram}")
    print(DIV)
    print(f"  Accuracy   : {m['Accuracy']:.4f}")
    print(f"  Precision  : {m['Precision']:.4f}  (weighted)")
    print(f"  Recall     : {m['Recall']:.4f}  (weighted)")
    print(f"  F-measure  : {m['F1']:.4f}  (weighted)")
    print(f"\n  Per-class breakdown:\n{m['ClassReport']}")
    print(f"  Confusion matrix (rows=true, cols=predicted):\n{m['ConfMatrix']}\n")


def main():
    parser = argparse.ArgumentParser(
        description="CIS*6530 Sub4 — multi-class OpCode classifier"
    )
    parser.add_argument("--dataset_dir", required=True)
    parser.add_argument("--output_dir",  default="figures")
    parser.add_argument("--random_seed", type=int, default=42)
    args = parser.parse_args()

    dataset_dir = Path(args.dataset_dir)
    output_dir  = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    y_train     = np.load(str(dataset_dir / "y_train.npy"))
    y_test      = np.load(str(dataset_dir / "y_test.npy"))
    class_names = list(np.load(str(dataset_dir / "label_encoder.npy"), allow_pickle=True))
    log.info("Classes (%d): %s", len(class_names), class_names)

    gram_data = {
        "1-gram": (
            sp.load_npz(str(dataset_dir / "X_train_1gram.npz")),
            sp.load_npz(str(dataset_dir / "X_test_1gram.npz")),
        ),
        "2-gram": (
            sp.load_npz(str(dataset_dir / "X_train_2gram.npz")),
            sp.load_npz(str(dataset_dir / "X_test_2gram.npz")),
        ),
    }

    classifiers = get_classifiers(args.random_seed)
    rows = []

    for gram_label, (X_train, X_test) in gram_data.items():
        gram_tag = gram_label.replace("-", "")
        log.info("--- %s | train=%s  test=%s ---",
                 gram_label, X_train.shape, X_test.shape)

        for clf_name, clf in classifiers.items():
            log.info("Training %s on %s …", clf_name, gram_label)
            clf.fit(X_train, y_train)
            y_pred  = clf.predict(X_test)
            metrics = evaluate(y_test, y_pred, class_names)

            print_run(clf_name, gram_label, metrics)

            np.save(str(output_dir / f"cm_{clf_name}_{gram_tag}.npy"),
                    metrics["ConfMatrix"])
            (output_dir / f"report_{clf_name}_{gram_tag}.txt").write_text(
                f"Classifier: {clf_name}\nN-gram: {gram_label}\n\n"
                + metrics["ClassReport"]
            )
            rows.append({
                "Classifier": clf_name,
                "N-gram":     gram_label,
                "Accuracy":   round(metrics["Accuracy"],  4),
                "Precision":  round(metrics["Precision"], 4),
                "Recall":     round(metrics["Recall"],    4),
                "F-measure":  round(metrics["F1"],        4),
            })

    df = pd.DataFrame(rows)
    csv_path = output_dir / "results_summary.csv"
    df.to_csv(str(csv_path), index=False)

    print(f"\n\n{DIV}")
    print("  FINAL RESULTS SUMMARY")
    print(DIV)
    print(df.to_string(index=False))
    print(DIV)
    log.info("Saved: %s", csv_path)


if __name__ == "__main__":
    main()
