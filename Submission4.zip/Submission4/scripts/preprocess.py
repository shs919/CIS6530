"""
preprocess.py
=============
CIS*6530 Submission 4 — OpCode Preprocessing Pipeline
Project 1 | Dr. Ali Dehghantanha

FILE FORMAT:
    Each .opcode file contains one x86 instruction per line as raw hex bytes,
    produced by the GHIDRA extraction script from Submission 3.
    Example:
        55
        89 e5
        83 ec 18
        ff d0
    Capstone disassembles each line into a mnemonic token.

ARCHITECTURE AUTO-DETECTION:
    The dataset contains a mix of 32-bit and 64-bit binaries.
    Each file is tested independently: if >10% of the first 300 decoded
    instructions are 'dec' in 32-bit mode (caused by REX prefix bytes being
    misread as DEC instructions), the file is treated as 64-bit.

LABEL INFERENCE:
    Filenames: <APT_GROUP>_<MalwareFamily>_<8hexhash>.opcode
    The 8-char hex hash is always the last segment.
    The malware family is always the second-to-last segment.
    Everything before = APT group label (may contain underscores or @).
    Examples:
        APT1_Gh0stRAT_4561510e.opcode        -> APT1
        admin@338_Gh0stRAT_0bff57a5.opcode   -> admin@338
        Ajax_Security_njRAT_2a80ede2.opcode  -> Ajax_Security
        APT19_CobaltStrike_372702d5.opcode   -> APT19

USAGE:
    python preprocess.py --opcode_dir path/to/Raw_Extracted_Files/ --output_dir dataset/

    Options:
        --test_size    float  Held-out fraction (default: 0.20)
        --random_seed  int    Global seed       (default: 42)
        --max_features int    TF-IDF vocab cap  (default: 10000)
        --verbose             Print per-file token counts

OUTPUT (in --output_dir):
    X_train_1gram.npz        Sparse TF-IDF train matrix, 1-gram
    X_test_1gram.npz         Sparse TF-IDF test  matrix, 1-gram
    X_train_2gram.npz        Sparse TF-IDF train matrix, 2-gram
    X_test_2gram.npz         Sparse TF-IDF test  matrix, 2-gram
    y_train.npy, y_test.npy  Integer class labels
    label_encoder.npy        APT group name array (index -> name)
    feature_names_1gram.npy  1-gram vocabulary
    feature_names_2gram.npy  2-gram vocabulary
    arch_map.txt             Per-file architecture decisions (audit log)
    preprocessing_summary.txt Human-readable run report

DEPENDENCIES:
    pip install capstone scikit-learn numpy scipy
"""

import re
import sys
import argparse
import logging
from pathlib import Path
from collections import Counter

import numpy as np
import scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

try:
    import capstone
    _CS_AVAILABLE = True
except ImportError:
    _CS_AVAILABLE = False

# ── Architecture detection ────────────────────────────────────────────────────

_CS32 = None
_CS64 = None

def _get_disassemblers():
    global _CS32, _CS64
    if not _CS_AVAILABLE:
        log.error("capstone not installed. Run: pip install capstone")
        sys.exit(1)
    if _CS32 is None:
        _CS32 = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
        _CS32.detail = False
        _CS64 = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
        _CS64.detail = False
    return _CS32, _CS64


def detect_arch(path: Path) -> int:
    """
    Auto-detect whether a file contains 32-bit or 64-bit x86 instructions.

    Method: disassemble the first 300 lines in 32-bit mode and count 'dec'
    mnemonics. REX prefix bytes (0x40-0x4F), which are modifier bytes in 64-bit
    code, are decoded as standalone DEC instructions in 32-bit mode, creating an
    abnormally high 'dec' frequency. A threshold of >10% signals 64-bit code.
    """
    cs32, _ = _get_disassemblers()
    lines = path.read_text(errors="replace").splitlines()[:300]
    mnems = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            raw = bytes.fromhex(line.replace(" ", ""))
            result = list(cs32.disasm(raw, 0x0))
            if result:
                mnems.append(result[0].mnemonic)
        except Exception:
            pass
    if not mnems:
        return 32
    dec_frac = mnems.count("dec") / len(mnems)
    return 64 if dec_frac > 0.10 else 32


# ── Label inference ───────────────────────────────────────────────────────────

_HEX8 = re.compile(r'^[0-9a-fA-F]{8}$')


def infer_label(path: Path) -> str:
    """
    Extract APT group label from: <APT_GROUP>_<MalwareFamily>_<8hexhash>.opcode
    Drops the last two underscore-segments (hash + malware family name).
    Works correctly for group names containing underscores (Ajax_Security)
    and special characters (admin@338).
    """
    parts = path.stem.split("_")
    if len(parts) >= 3 and _HEX8.match(parts[-1]):
        label_parts = parts[:-2]
    elif len(parts) >= 2:
        label_parts = parts[:-1]
    else:
        label_parts = parts
    return "_".join(label_parts) if label_parts else path.stem


# ── Per-file parsing ──────────────────────────────────────────────────────────

def parse_opcode_file(path: Path, verbose: bool = False) -> list:
    """
    Disassemble one .opcode file (hex-byte lines) into a list of mnemonics.
    Architecture (32/64-bit) is detected automatically per file.
    Lines that fail hex conversion or Capstone decoding are silently skipped.
    """
    cs32, cs64 = _get_disassemblers()
    arch = detect_arch(path)
    cs   = cs64 if arch == 64 else cs32

    tokens = []
    failed = 0

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        log.warning("Cannot read %s: %s", path.name, exc)
        return tokens, arch

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            raw = bytes.fromhex(line.replace(" ", ""))
        except ValueError:
            failed += 1
            continue

        result = list(cs.disasm(raw, 0x0))
        if result:
            tokens.append(result[0].mnemonic)
        else:
            failed += 1

    if verbose:
        log.info(
            "  %-52s  x86-%d  tokens=%-7d  skipped=%d",
            path.name, arch, len(tokens), failed,
        )
    return tokens, arch


# ── Dataset loader ────────────────────────────────────────────────────────────

def load_corpus(opcode_dir: Path, verbose: bool, output_dir: Path):
    files = sorted(opcode_dir.rglob("*.opcode"))
    if not files:
        log.error("No .opcode files found under '%s'.", opcode_dir)
        sys.exit(1)

    log.info("Found %d .opcode files.", len(files))
    corpus, labels, arch_log = [], [], []

    for fp in files:
        label = infer_label(fp)
        tokens, arch = parse_opcode_file(fp, verbose=verbose)
        arch_log.append(f"x86-{arch}  {fp.name}")

        if not tokens:
            log.warning("Skipping (no decodable instructions): %s", fp.name)
            continue

        corpus.append(" ".join(tokens))
        labels.append(label)

    # Save architecture audit log
    (output_dir / "arch_map.txt").write_text("\n".join(arch_log))

    log.info(
        "Loaded %d samples across %d classes: %s",
        len(corpus), len(set(labels)), sorted(set(labels)),
    )
    return corpus, labels


# ── TF-IDF builder ────────────────────────────────────────────────────────────

def build_tfidf(train_docs, test_docs, ngram_range, max_features):
    """
    Fit TF-IDF on training data ONLY, then transform both splits.

    LEAKAGE PREVENTION:
        The TF-IDF vectoriser's vocabulary and IDF weights are derived
        exclusively from train_docs via fit_transform().
        test_docs is processed with transform() only — no test-set
        information influences the feature representation.
        This mirrors real deployment: unknown n-grams in the test set
        are silently ignored.
    """
    vec = TfidfVectorizer(
        ngram_range=ngram_range,
        max_features=max_features,
        sublinear_tf=True,         # log(1+tf): suppresses ubiquitous opcodes
        analyzer="word",
        token_pattern=r"[a-z][a-z0-9]+",
    )
    X_train = vec.fit_transform(train_docs)   # fit + transform on train ONLY
    X_test  = vec.transform(test_docs)         # transform only  (no leakage)
    return X_train, X_test, vec


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CIS*6530 Sub4 — hex-byte opcode preprocessing pipeline"
    )
    parser.add_argument("--opcode_dir",    required=True)
    parser.add_argument("--output_dir",    default="dataset")
    parser.add_argument("--test_size",     type=float, default=0.20)
    parser.add_argument("--random_seed",   type=int,   default=42)
    parser.add_argument("--max_features",  type=int,   default=10000)
    parser.add_argument("--verbose",       action="store_true")
    args = parser.parse_args()

    opcode_dir = Path(args.opcode_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Disassemble all files with per-file arch detection
    corpus, labels = load_corpus(opcode_dir, args.verbose, output_dir)

    # 2. Encode labels to integers
    le = LabelEncoder()
    y  = le.fit_transform(labels)
    log.info("Label mapping: %s", dict(zip(le.classes_, le.transform(le.classes_))))

    # 3. Stratified 80/20 train/test split
    #    stratify=y ensures every APT class is proportionally represented
    #    in both partitions — critical with imbalanced group sample counts.
    corpus_train, corpus_test, y_train, y_test = train_test_split(
        corpus, y,
        test_size=args.test_size,
        random_state=args.random_seed,
        stratify=y,
    )
    log.info(
        "Split: %d train / %d test  (seed=%d, stratified)",
        len(y_train), len(y_test), args.random_seed,
    )

    # 4. Build 1-gram TF-IDF features
    log.info("Building 1-gram TF-IDF features …")
    X_tr1, X_te1, vec1 = build_tfidf(
        corpus_train, corpus_test, (1, 1), args.max_features)
    log.info("  1-gram vocab size: %d features", X_tr1.shape[1])

    # 5. Build 2-gram TF-IDF features
    log.info("Building 2-gram TF-IDF features …")
    X_tr2, X_te2, vec2 = build_tfidf(
        corpus_train, corpus_test, (2, 2), args.max_features)
    log.info("  2-gram vocab size: %d features", X_tr2.shape[1])

    # 6. Save all artefacts
    sp.save_npz(str(output_dir / "X_train_1gram.npz"), X_tr1)
    sp.save_npz(str(output_dir / "X_test_1gram.npz"),  X_te1)
    sp.save_npz(str(output_dir / "X_train_2gram.npz"), X_tr2)
    sp.save_npz(str(output_dir / "X_test_2gram.npz"),  X_te2)
    np.save(str(output_dir / "y_train.npy"),            y_train)
    np.save(str(output_dir / "y_test.npy"),             y_test)
    np.save(str(output_dir / "label_encoder.npy"),      le.classes_)
    np.save(str(output_dir / "feature_names_1gram.npy"), vec1.get_feature_names_out())
    np.save(str(output_dir / "feature_names_2gram.npy"), vec2.get_feature_names_out())

    # 7. Human-readable summary
    u_tr, c_tr = np.unique(y_train, return_counts=True)
    u_te, c_te = np.unique(y_test,  return_counts=True)

    lines = [
        "=" * 64,
        "  CIS*6530 Submission 4 — Preprocessing Summary",
        "=" * 64,
        f"  OpCode directory  : {opcode_dir.resolve()}",
        f"  Total samples     : {len(corpus)}",
        f"  APT classes       : {sorted(set(labels))}",
        f"  Random seed       : {args.random_seed}",
        f"  Test fraction     : {args.test_size}",
        f"  Train / Test      : {len(y_train)} / {len(y_test)}",
        f"  1-gram vocab dim  : {X_tr1.shape[1]}",
        f"  2-gram vocab dim  : {X_tr2.shape[1]}",
        "",
        "  Train class distribution:",
    ] + [f"    {le.classes_[i]:28s}: {c}" for i, c in zip(u_tr, c_tr)] + [
        "",
        "  Test class distribution:",
    ] + [f"    {le.classes_[i]:28s}: {c}" for i, c in zip(u_te, c_te)] + [
        "=" * 64,
    ]

    summary = "\n".join(lines)
    print("\n" + summary)
    (output_dir / "preprocessing_summary.txt").write_text(summary)
    log.info("All artefacts saved to '%s'", output_dir)


if __name__ == "__main__":
    main()
