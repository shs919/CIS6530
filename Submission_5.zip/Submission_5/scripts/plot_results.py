"""
plot_results.py
===============
CIS*6530 Submission 5 — Visualisation & Baseline Comparison
Project 1 | Dr. Ali Dehghantanha

Generates all figures for the technical report:
  1. Training loss & accuracy curves
  2. CNN confusion matrix (raw + normalised)
  3. Comparison bar chart: CNN vs SVM vs KNN vs Decision Tree

USAGE:
    python plot_results.py --results_dir figures/ --sub4_csv ../sub4/figures/results_summary.csv

DEPENDENCIES:
    pip install matplotlib seaborn numpy pandas
"""

import argparse
import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

DPI    = 180
COLORS = ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#D55E00", "#56B4E9"]


# ── Figure 1 — Training curves ────────────────────────────────────────────────

def plot_training_curves(history: dict, save_path: Path):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    for ax, metric, val_metric, title in zip(
        axes,
        ["loss",     "accuracy"],
        ["val_loss", "val_accuracy"],
        ["Loss (Sparse Categorical Crossentropy)", "Accuracy"],
    ):
        epochs = range(1, len(history[metric]) + 1)
        ax.plot(epochs, history[metric],     color=COLORS[0], linewidth=2, label="Train")
        ax.plot(epochs, history[val_metric], color=COLORS[1], linewidth=2,
                linestyle="--", label="Validation")
        ax.set_title(title, fontsize=12, fontweight="bold", pad=10)
        ax.set_xlabel("Epoch", fontsize=10)
        ax.set_ylabel(title.split("(")[0].strip(), fontsize=10)
        ax.legend(fontsize=10)
        ax.grid(linestyle="--", alpha=0.4)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle(
        "CNN Training History — McLaughlin et al. 2017 Architecture",
        fontsize=13, fontweight="bold",
    )
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


# ── Figure 2 — CNN confusion matrix ──────────────────────────────────────────

def plot_cnn_confusion_matrix(cm: np.ndarray, class_names: list, save_path: Path):
    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-12)
    n = len(class_names)
    fig_w = max(14, n * 1.2 + 4)
    fig_h = max(5,  n * 0.55 + 3)

    fig, axes = plt.subplots(1, 2, figsize=(fig_w, fig_h))
    for ax, data, subtitle, fmt in zip(
        axes,
        [cm, cm_norm],
        ["Raw counts", "Row-normalised (recall per class)"],
        ["d", ".2f"],
    ):
        sns.heatmap(
            data, ax=ax, annot=True, fmt=fmt,
            cmap="Blues",
            xticklabels=class_names, yticklabels=class_names,
            linewidths=0.4, linecolor="#cccccc",
            cbar_kws={"shrink": 0.72, "aspect": 28},
            vmin=0, vmax=(None if data is cm else 1.0),
        )
        ax.set_title(subtitle, fontsize=11, pad=8)
        ax.set_xlabel("Predicted label", fontsize=10)
        ax.set_ylabel("True label",      fontsize=10)
        ax.tick_params(axis="x", rotation=45, labelsize=8)
        ax.tick_params(axis="y", rotation=0,  labelsize=8)

    fig.suptitle(
        "CNN (McLaughlin et al. 2017)  |  10-Class APT Attribution",
        fontsize=13, fontweight="bold", y=1.02,
    )
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


# ── Figure 3 — Comparison vs Sub4 baselines ───────────────────────────────────

def plot_comparison(cnn_results: dict, sub4_csv: Path, save_path: Path):
    """
    Direct apples-to-apples comparison between CNN and all Sub4 classifiers.
    Uses the same dataset/split/metrics for a controlled comparison.
    """
    # Sub4 results
    df4 = pd.read_csv(str(sub4_csv))
    # Label each row
    df4["Label"] = df4["Classifier"].map({
        "SVM":          "SVM (RBF)",
        "KNN_k3":       "KNN (k=3)",
        "DecisionTree": "Decision Tree",
    }) + "\n" + df4["N-gram"]

    # CNN result — single row
    cnn_row = {
        "Label":     "CNN\n(McLaughlin\n2017)",
        "Accuracy":  cnn_results["Accuracy"],
        "Precision": cnn_results["Precision"],
        "Recall":    cnn_results["Recall"],
        "F-measure": cnn_results["F-measure"],
    }

    # Combine
    metric_cols = ["Accuracy", "Precision", "Recall", "F-measure"]
    labels = list(df4["Label"]) + [cnn_row["Label"]]
    values = {m: list(df4[m]) + [cnn_row[m]] for m in metric_cols}

    n      = len(labels)
    x      = np.arange(n)
    n_met  = len(metric_cols)
    width  = 0.17

    fig, ax = plt.subplots(figsize=(max(14, n * 1.6), 7))

    for i, (metric, color) in enumerate(zip(metric_cols, COLORS)):
        offset = (i - n_met / 2 + 0.5) * width
        # Highlight CNN bar with slightly different style
        bar_colors = [color] * (n - 1) + [color]
        edgecolors = ["white"] * (n - 1) + ["black"]
        linewidths = [0.5] * (n - 1) + [1.5]
        bars = ax.bar(
            x + offset, values[metric], width,
            label=metric,
            color=bar_colors,
            edgecolor=edgecolors,
            linewidth=linewidths,
            zorder=3,
        )
        for bar in bars:
            h = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2, h + 0.007,
                f"{h:.3f}", ha="center", va="bottom",
                fontsize=6, rotation=90, color="#333333",
            )

    # Vertical line separating baselines from CNN
    ax.axvline(x=n - 1.5, color="grey", linestyle="--", linewidth=1.2, alpha=0.7)
    ax.text(n - 1.5, 1.12, "Deep Learning →", ha="center",
            fontsize=9, color="grey", style="italic")

    ax.set_title(
        "CIS*6530 – Submission 5  |  CNN vs Classical Baselines (Submission 4)\n"
        "Same Dataset, Same Split, Same Metrics — Controlled Comparison",
        fontsize=12, fontweight="bold", pad=14,
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylim(0, 1.22)
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter("%.2f"))
    ax.set_ylabel("Score (weighted average)", fontsize=11)
    ax.grid(axis="y", linestyle="--", alpha=0.35, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)

    handles, labs = ax.get_legend_handles_labels()
    ax.legend(handles, labs, loc="upper right", ncol=4, fontsize=10, frameon=False)

    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


# ── Figure 4 — Summary heatmap including CNN ─────────────────────────────────

def plot_full_heatmap(cnn_results: dict, sub4_csv: Path, save_path: Path):
    df4 = pd.read_csv(str(sub4_csv))
    clf_map = {"SVM": "SVM (RBF)", "KNN_k3": "KNN (k=3)", "DecisionTree": "Decision Tree"}
    df4["Condition"] = df4["Classifier"].map(clf_map) + " | " + df4["N-gram"]

    metric_cols = ["Accuracy", "Precision", "Recall", "F-measure"]
    rows = df4.set_index("Condition")[metric_cols].copy()

    # Add CNN row
    cnn_series = pd.Series(
        {m: cnn_results[m] for m in metric_cols},
        name="CNN | McLaughlin 2017",
    )
    rows = pd.concat([rows, cnn_series.to_frame().T])

    fig, ax = plt.subplots(figsize=(10, max(5, len(rows) * 0.75 + 1.5)))
    sns.heatmap(
        rows, ax=ax, annot=True, fmt=".4f",
        cmap="YlGnBu", vmin=0, vmax=1,
        linewidths=0.5, linecolor="#cccccc",
        cbar_kws={"label": "Score", "shrink": 0.75},
        annot_kws={"size": 10},
    )
    ax.set_title(
        "Full Performance Summary — Submission 4 Baselines + CNN (Submission 5)",
        fontsize=12, fontweight="bold", pad=14,
    )
    ax.tick_params(axis="x", rotation=0, labelsize=10)
    ax.tick_params(axis="y", rotation=0, labelsize=9)
    plt.tight_layout()
    fig.savefig(str(save_path), dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved: %s", save_path.name)


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CIS*6530 Sub5 — generate result figures"
    )
    parser.add_argument("--results_dir", required=True)
    parser.add_argument("--sub4_csv",    required=True,
                        help="Path to Sub4 results_summary.csv for comparison")
    parser.add_argument("--output_dir",  default=None)
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    output_dir  = Path(args.output_dir) if args.output_dir else results_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load CNN results
    with open(str(results_dir / "cnn_results.json")) as f:
        cnn_results = json.load(f)

    history = np.load(
        str(results_dir / "training_history.npy"), allow_pickle=True).item()
    cm = np.load(str(results_dir / "cnn_confusion_matrix.npy"))
    class_names = cnn_results["class_names"]

    log.info("Generating training curves …")
    plot_training_curves(history, output_dir / "cnn_training_curves.png")

    log.info("Generating CNN confusion matrix …")
    plot_cnn_confusion_matrix(cm, class_names, output_dir / "cnn_confusion_matrix.png")

    log.info("Generating comparison bar chart …")
    plot_comparison(cnn_results, Path(args.sub4_csv),
                    output_dir / "cnn_vs_baselines.png")

    log.info("Generating full summary heatmap …")
    plot_full_heatmap(cnn_results, Path(args.sub4_csv),
                      output_dir / "full_summary_heatmap.png")

    log.info("All figures saved to: %s", output_dir)


if __name__ == "__main__":
    main()
