"""
train_evaluate.py
=================
CIS*6530 Submission 5 — CNN Training & Evaluation Pipeline
Project 1 | Dr. Ali Dehghantanha

Reads raw .opcode files (hex-byte format from Submission 3/4),
encodes opcode sequences, trains the McLaughlin et al. CNN,
and evaluates with all required metrics.

USAGE:
    python train_evaluate.py --opcode_dir Raw_Extracted_Files/ --output_dir figures/

    Options:
        --sequence_length  int    Pad/truncate length (default: 1000)
        --embedding_dim    int    Embedding size     (default: 64)
        --filters          int    Conv filters       (default: 64)
        --epochs           int    Training epochs    (default: 50)
        --batch_size       int    Batch size         (default: 16)
        --test_size        float  Test fraction      (default: 0.20)
        --random_seed      int    Global seed        (default: 42)

OUTPUT (in --output_dir):
    cnn_results.json         All metrics for report table
    cnn_confusion_matrix.npy Confusion matrix array
    training_history.npy     Loss/accuracy curves per epoch
    cnn_model/               Saved Keras model

DEPENDENCIES:
    pip install tensorflow capstone scikit-learn numpy pandas
"""

import re
import sys
import json
import argparse
import logging
import numpy as np
from pathlib import Path
from collections import Counter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

# ── Architecture detection (same logic as preprocess.py) ─────────────────────
_HEX8 = re.compile(r'^[0-9a-fA-F]{8}$')

try:
    import capstone
    _CS32 = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    _CS32.detail = False
    _CS64 = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    _CS64.detail = False
    _CS_OK = True
except ImportError:
    _CS_OK = False


def detect_arch(path: Path) -> int:
    """Detect x86-32 vs x86-64 via REX prefix heuristic."""
    lines = path.read_text(errors="replace").splitlines()[:300]
    mnems = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            raw = bytes.fromhex(line.replace(" ", ""))
            r = list(_CS32.disasm(raw, 0x0))
            if r:
                mnems.append(r[0].mnemonic)
        except Exception:
            pass
    if not mnems:
        return 32
    return 64 if mnems.count("dec") / len(mnems) > 0.10 else 32


def infer_label(path: Path) -> str:
    parts = path.stem.split("_")
    if len(parts) >= 3 and _HEX8.match(parts[-1]):
        return "_".join(parts[:-2])
    elif len(parts) >= 2:
        return "_".join(parts[:-1])
    return path.stem


def parse_opcode_file(path: Path) -> list:
    """Disassemble hex-byte file into list of mnemonic strings."""
    if not _CS_OK:
        log.error("capstone not installed. Run: pip install capstone")
        sys.exit(1)
    arch = detect_arch(path)
    cs   = _CS64 if arch == 64 else _CS32
    tokens = []
    try:
        for line in path.read_text(errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = bytes.fromhex(line.replace(" ", ""))
                r = list(cs.disasm(raw, 0x0))
                if r:
                    tokens.append(r[0].mnemonic)
            except Exception:
                pass
    except OSError:
        pass
    return tokens


# ── Vocabulary & encoding ─────────────────────────────────────────────────────

def build_vocab(all_sequences: list) -> dict:
    """
    Build opcode vocabulary from training sequences.
    Token 0 is reserved for padding.
    Returns: {mnemonic: integer_id}
    """
    counter = Counter(tok for seq in all_sequences for tok in seq)
    vocab = {"<PAD>": 0}
    for i, (tok, _) in enumerate(counter.most_common(), start=1):
        vocab[tok] = i
    return vocab


def encode_and_pad(sequences: list, vocab: dict, max_len: int) -> np.ndarray:
    """
    Encode mnemonic sequences to integer arrays and pad/truncate to max_len.
    Unknown tokens (unseen at train time) map to 0 (same as padding).
    """
    encoded = []
    for seq in sequences:
        ids = [vocab.get(tok, 0) for tok in seq]
        # Truncate if longer than max_len
        ids = ids[:max_len]
        # Pad with 0 if shorter than max_len
        ids += [0] * (max_len - len(ids))
        encoded.append(ids)
    return np.array(encoded, dtype=np.int32)


# ── Dataset loading ───────────────────────────────────────────────────────────

def load_dataset(opcode_dir: Path):
    files = sorted(opcode_dir.rglob("*.opcode"))
    if not files:
        log.error("No .opcode files found under '%s'.", opcode_dir)
        sys.exit(1)
    log.info("Found %d .opcode files.", len(files))

    sequences, labels = [], []
    for fp in files:
        label  = infer_label(fp)
        tokens = parse_opcode_file(fp)
        if not tokens:
            log.warning("Skipping empty file: %s", fp.name)
            continue
        sequences.append(tokens)
        labels.append(label)
        log.info("  %-52s  label=%-20s  len=%d", fp.name, label, len(tokens))

    log.info("Loaded %d samples, %d classes: %s",
             len(sequences), len(set(labels)), sorted(set(labels)))
    return sequences, labels


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CIS*6530 Sub5 — CNN training and evaluation"
    )
    parser.add_argument("--opcode_dir",     required=True)
    parser.add_argument("--output_dir",     default="figures")
    parser.add_argument("--sequence_length",type=int,   default=1000)
    parser.add_argument("--embedding_dim",  type=int,   default=64)
    parser.add_argument("--filters",        type=int,   default=64)
    parser.add_argument("--epochs",         type=int,   default=50)
    parser.add_argument("--batch_size",     type=int,   default=16)
    parser.add_argument("--test_size",      type=float, default=0.20)
    parser.add_argument("--random_seed",    type=int,   default=42)
    parser.add_argument("--model_type",  choices=["paper_exact","enhanced"], default="enhanced",
                        help="paper_exact: uses paper's exact hyperparams (emb=8, 1 conv, k=8, hidden=16, RMSProp). enhanced: uses justified adaptations.")
    args = parser.parse_args()

    import tensorflow as tf
    from tensorflow import keras
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score,
        f1_score, confusion_matrix, classification_report,
    )
    from cnn_model import build_cnn_model, build_paper_exact_model, get_model_summary

    # Reproducibility
    np.random.seed(args.random_seed)
    tf.random.set_seed(args.random_seed)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load raw sequences
    sequences, labels = load_dataset(Path(args.opcode_dir))

    # 2. Encode class labels
    le = LabelEncoder()
    y  = le.fit_transform(labels)
    class_names = list(le.classes_)
    log.info("Classes: %s", class_names)

    # 3. Stratified 80/20 split — SAME seed as Submission 4 for fair comparison
    seq_train, seq_test, y_train, y_test = train_test_split(
        sequences, y,
        test_size=args.test_size,
        random_state=args.random_seed,
        stratify=y,
    )
    log.info("Split: %d train / %d test  (seed=%d, stratified)",
             len(y_train), len(y_test), args.random_seed)

    # 4. Build vocabulary from training data ONLY (leakage prevention)
    vocab = build_vocab(seq_train)
    vocab_size = len(vocab)
    log.info("Vocabulary size: %d unique opcodes", vocab_size)

    # Save vocab for reproducibility
    np.save(str(output_dir / "cnn_vocab.npy"),
            np.array(list(vocab.items()), dtype=object))
    np.save(str(output_dir / "cnn_label_encoder.npy"), le.classes_)

    # 5. Encode and pad sequences
    X_train = encode_and_pad(seq_train, vocab, args.sequence_length)
    X_test  = encode_and_pad(seq_test,  vocab, args.sequence_length)
    log.info("X_train: %s  X_test: %s", X_train.shape, X_test.shape)

    # 6. Build CNN model
    if args.model_type == "paper_exact":
        log.info("Building PAPER-EXACT model (emb=8, 1 conv, k=8, hidden=16, RMSProp)")
        model = build_paper_exact_model(
            vocab_size=vocab_size + 1,
            sequence_length=args.sequence_length,
            n_classes=len(class_names),
        )
    else:
        log.info("Building ENHANCED model (emb=64, 2 conv, k=5, hidden=128, Adam)")
        model = build_cnn_model(
            vocab_size=vocab_size + 1,
            embedding_dim=args.embedding_dim,
            sequence_length=args.sequence_length,
            n_classes=len(class_names),
            filters=args.filters,
            kernel_size=5,
            dropout_rate=0.3,
        )
    print(get_model_summary(model))

    # 7. Callbacks
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=10,
            restore_best_weights=True,
            verbose=1,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=5,
            min_lr=1e-6,
            verbose=1,
        ),
    ]

    # 8. Train
    log.info("Training CNN for up to %d epochs …", args.epochs)
    history = model.fit(
        X_train, y_train,
        epochs=args.epochs,
        batch_size=args.batch_size,
        validation_split=0.2,
        callbacks=callbacks,
        verbose=1,
    )

    # Save training history
    hist_dict = {
        "loss":     history.history.get("loss", []),
        "val_loss": history.history.get("val_loss", []),
        "accuracy": history.history.get("accuracy", []),
        "val_accuracy": history.history.get("val_accuracy", []),
    }
    np.save(str(output_dir / "training_history.npy"), hist_dict)

    # 9. Evaluate on test set
    log.info("Evaluating on test set …")
    y_pred_probs = model.predict(X_test, verbose=0)
    y_pred       = np.argmax(y_pred_probs, axis=1)

    avg = "weighted"
    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average=avg, zero_division=0)
    rec  = recall_score(y_test, y_pred, average=avg, zero_division=0)
    f1   = f1_score(y_test, y_pred, average=avg, zero_division=0)
    cm   = confusion_matrix(y_test, y_pred)
    report = classification_report(
        y_test, y_pred, target_names=class_names, zero_division=0, digits=4)

    print("\n" + "=" * 60)
    print("  CNN EVALUATION RESULTS")
    print("=" * 60)
    print(f"  Accuracy   : {acc:.4f}")
    print(f"  Precision  : {prec:.4f}  (weighted)")
    print(f"  Recall     : {rec:.4f}  (weighted)")
    print(f"  F-measure  : {f1:.4f}  (weighted)")
    print(f"\n  Per-class report:\n{report}")
    print(f"  Confusion matrix:\n{cm}")
    print("=" * 60)

    # 10. Save results
    results = {
        "model":        f"CNN-{args.model_type} (McLaughlin et al. 2017)",
        "Accuracy":     round(float(acc),  4),
        "Precision":    round(float(prec), 4),
        "Recall":       round(float(rec),  4),
        "F-measure":    round(float(f1),   4),
        "class_names":  class_names,
        "classification_report": report,
        "hyperparameters": {
            "sequence_length": args.sequence_length,
            "embedding_dim":   args.embedding_dim,
            "filters":         args.filters,
            "kernel_size":     5,
            "dropout_rate":    0.3,
            "epochs_run":      len(history.history["loss"]),
            "batch_size":      args.batch_size,
            "optimizer":       "Adam(lr=0.001)",
            "random_seed":     args.random_seed,
        },
    }
    with open(str(output_dir / f"cnn_results_{args.model_type}.json"), "w") as f:
        json.dump(results, f, indent=2)

    np.save(str(output_dir / f"cnn_confusion_matrix_{args.model_type}.npy"), cm)

    # 11. Save model
    model_path = output_dir / f"cnn_model_{args.model_type}.keras"
    model.save(str(model_path))
    log.info("Model saved to %s", model_path)

    log.info("All results saved to '%s'", output_dir)
    return results


if __name__ == "__main__":
    main()
