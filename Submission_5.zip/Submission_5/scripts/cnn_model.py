"""
cnn_model.py
============
CIS*6530 Submission 5 — CNN Architecture Implementations
Project 1 | Dr. Ali Dehghantanha

Implements TWO variants of the McLaughlin et al. (2017) architecture:

1. build_paper_exact_model() — paper's exact hyperparameters:
   embedding_dim=8, 1 Conv1D(64, k=8), GlobalMaxPool, Dense(16), RMSProp
   Total params: ~8,970

2. build_cnn_model() — enhanced variant with justified adaptations:
   embedding_dim=64, 2 Conv1D(64, k=5), MaxPool+GlobalMaxPool, Dense(128), Adam
   Total params: ~79,498
   Rationale: larger embedding for x86 vocab, deeper network for 10 classes,
              Adam optimizer for better convergence with early stopping

Both use the same core pipeline: Embedding → Conv1D → Pool → Dense → Softmax

REFERENCE:
    McLaughlin et al. (2017). Deep Android Malware Detection.
    CODASPY '17, ACM. DOI: 10.1145/3029806.3029823

DEPENDENCIES:
    pip install tensorflow
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers


def build_paper_exact_model(
    vocab_size: int,
    sequence_length: int = 1000,
    n_classes: int = 10,
) -> keras.Model:
    """
    Paper-exact implementation of McLaughlin et al. (2017).

    Hyperparameters taken directly from Section 4 of the paper:
        embedding_dim = 8       ("8-dimensional embedding space")
        num_conv_layers = 1     ("only a single convolutional layer")
        filters = 64            ("64 convolutional filters")
        kernel_size = 8         ("of length 8")
        hidden_units = 16       ("16 neurons in the hidden fully connected layer")
        optimizer = RMSProp     (Section 3.3, learning_rate=1e-2)
        batch_size = 16         (Section 4)

    Adaptations from binary Android detection to 10-class x86 attribution:
        - Output: 10-unit Softmax instead of 2-unit Sigmoid
        - Loss: Sparse categorical crossentropy instead of binary crossentropy
        - Dropout(0.3) added (not in paper; justified regularisation)
    """
    model = keras.Sequential([
        keras.Input(shape=(sequence_length,), name="opcode_sequence"),
        layers.Embedding(vocab_size, 8, name="embedding"),           # k=8 from paper
        layers.Conv1D(64, kernel_size=8, activation="relu",          # single layer, k=8
                      padding="same", name="conv1"),
        layers.GlobalMaxPooling1D(name="global_pool"),                # max over length
        layers.Dense(16, activation="relu", name="fc1"),             # 16 units from paper
        layers.Dropout(0.3, name="dropout"),                          # added regularisation
        layers.Dense(n_classes, activation="softmax", name="output"),
    ], name="McLaughlin2017_PaperExact")

    model.compile(
        optimizer=keras.optimizers.RMSprop(learning_rate=1e-2),      # RMSProp from paper
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def build_cnn_model(
    vocab_size: int,
    embedding_dim: int = 64,
    sequence_length: int = 1000,
    n_classes: int = 10,
    filters: int = 64,
    kernel_size: int = 5,
    dropout_rate: float = 0.3,
) -> keras.Model:
    """
    Enhanced variant of McLaughlin et al. (2017) with justified adaptations.

    Deviations from paper and rationale:
        embedding_dim=64  (paper=8):  x86 has 449 opcodes vs 218 Dalvik;
                                       larger vocab benefits from richer embeddings
        num_conv_layers=2 (paper=1):  paper explicitly designs single layer for
                                       small datasets; 2 layers capture hierarchical
                                       patterns for 10-class vs 2-class problem
        kernel_size=5     (paper=8):  x86 instructions are shorter sequences;
                                       kernel=5 captures local patterns effectively
        hidden_units=128  (paper=16): 10-class output requires more representational
                                       capacity than binary classification
        Adam              (RMSProp):  Adam's adaptive moments improve convergence
                                       with EarlyStopping callbacks
    """
    model = keras.Sequential([
        keras.Input(shape=(sequence_length,), name="opcode_sequence"),
        layers.Embedding(vocab_size, embedding_dim, name="opcode_embedding"),
        layers.Conv1D(filters, kernel_size=kernel_size, activation="relu",
                      padding="same", name="conv1"),
        layers.MaxPooling1D(pool_size=2, name="pool1"),
        layers.Conv1D(filters, kernel_size=kernel_size, activation="relu",
                      padding="same", name="conv2"),
        layers.GlobalMaxPooling1D(name="global_pool"),
        layers.Dense(128, activation="relu", name="fc1"),
        layers.Dropout(dropout_rate, name="dropout"),
        layers.Dense(n_classes, activation="softmax", name="output"),
    ], name="McLaughlin2017_Enhanced")

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def get_model_summary(model: keras.Model) -> str:
    lines = []
    model.summary(print_fn=lambda x: lines.append(x))
    return "\n".join(lines)


if __name__ == "__main__":
    print("=== Paper-Exact Model ===")
    m1 = build_paper_exact_model(vocab_size=450, n_classes=10)
    print(get_model_summary(m1))
    print("\n=== Enhanced Model ===")
    m2 = build_cnn_model(vocab_size=450, n_classes=10)
    print(get_model_summary(m2))
