# CIS*6530 — Submission 5: Deep Malware Detection CNN

**Course:** CIS*6530 – Cyber Threat Intelligence and Adversarial Risk Analysis  
**Instructor:** Dr. Ali Dehghantanha | **TA:** Izabela Savic  
**Project:** Project 1 | **Deadline:** April 7, 2025 by 16:00 EST | **Weight:** 30%

---

## Overview

Implements the Convolutional Neural Network method from:

> McLaughlin, N., Martinez del Rincon, J., Kang, B., et al. (2017).
> **Deep Android Malware Detection.** CODASPY '17, ACM.

The method is adapted for multi-class x86 Windows/Linux OpCode attribution
across 10 APT groups (Project 1 dataset, 77 samples).

---

## Repository Structure

```
submission5/
├── scripts/
│   ├── cnn_model.py        # CNN architecture (McLaughlin et al. 2017)
│   ├── train_evaluate.py   # Training pipeline, evaluation, all metrics
│   └── plot_results.py     # Training curves, confusion matrix, comparison chart
├── figures/
│   ├── cnn_results.json            # All CNN metrics
│   ├── cnn_confusion_matrix.npy    # Confusion matrix array
│   ├── training_history.npy        # Loss/accuracy per epoch
│   ├── cnn_training_curves.png     # Figure 1: training history
│   ├── cnn_confusion_matrix.png    # Figure 2: confusion matrix
│   ├── cnn_vs_baselines.png        # Figure 3: CNN vs Sub4 classifiers
│   └── full_summary_heatmap.png    # Figure 4: complete performance heatmap
└── README.md
```

---

## CNN Architecture (McLaughlin et al. 2017)

```
Input: opcode sequence (integer-encoded, padded to length 1000)
  → Embedding(vocab_size, 64)
  → Conv1D(filters=64, kernel=5, activation=ReLU)
  → MaxPooling1D(pool_size=2)
  → Conv1D(filters=64, kernel=5, activation=ReLU)
  → GlobalMaxPooling1D
  → Dense(128, ReLU)
  → Dropout(0.3)
  → Dense(10, Softmax)       ← 10 APT group classes

Total parameters: 79,498
Optimizer: Adam(lr=0.001)
Loss: Sparse Categorical Crossentropy
```

**Adaptations from original paper** (Android binary → x86 multi-class):
- Output: 10-class Softmax instead of binary Sigmoid
- Input: x86 Windows/Linux opcodes instead of Dalvik Android opcodes  
- Loss: Sparse categorical crossentropy instead of binary crossentropy

---

## Dependencies

```bash
pip install tensorflow capstone scikit-learn numpy pandas matplotlib seaborn
```

Python 3.9+. No GPU required (CPU training ~2 minutes for 77 samples).

---

## Run — 2 Steps

### Step 1: Train & Evaluate

```bash
python scripts/train_evaluate.py \
    --opcode_dir  Raw_Extracted_Files/ \
    --output_dir  figures/ \
    --sequence_length 1000 \
    --embedding_dim   64 \
    --filters         64 \
    --epochs          50 \
    --batch_size      16 \
    --test_size       0.20 \
    --random_seed     42
```

**What it does:**
- Disassembles hex-byte .opcode files using Capstone (per-file 32/64-bit detection)
- Builds vocabulary from training data only (leakage prevention)
- Encodes sequences as integer arrays, pads to length 1000
- Trains CNN with EarlyStopping (patience=10) and ReduceLROnPlateau
- Evaluates: Accuracy, Precision, Recall, F-measure, Confusion Matrix
- Saves all results to `figures/`

### Step 2: Generate Figures

```bash
python scripts/plot_results.py \
    --results_dir figures/ \
    --sub4_csv    path/to/sub4/figures/results_summary.csv \
    --output_dir  figures/
```

**Generates:**
- `cnn_training_curves.png` — loss and accuracy per epoch
- `cnn_confusion_matrix.png` — raw + row-normalised confusion matrix
- `cnn_vs_baselines.png` — CNN vs all Sub4 classifiers (controlled comparison)
- `full_summary_heatmap.png` — complete heatmap including all 7 methods

---

## Results

### CNN vs Submission 4 Baselines (same dataset, split, metrics)

| Method | Accuracy | Precision | Recall | F-measure |
|---|---|---|---|---|
| CNN (McLaughlin 2017) | 0.5625 | 0.5208 | 0.5625 | 0.5375 |
| SVM (RBF) 1-gram | 0.6250 | 0.5104 | 0.6250 | 0.5542 |
| SVM (RBF) 2-gram | 0.6250 | 0.5833 | 0.6250 | 0.6000 |
| KNN (k=3) 1-gram | 0.6250 | 0.5625 | 0.6250 | 0.5833 |
| KNN (k=3) 2-gram | 0.5625 | 0.5000 | 0.5625 | 0.5208 |
| Decision Tree 1-gram | 0.5625 | 0.5000 | 0.5625 | 0.5250 |
| **Decision Tree 2-gram** | **0.7500** | **0.7500** | **0.7500** | **0.7333** |

All metrics: weighted average. Train/test: 80/20 stratified, seed=42.

### Key Findings
- CNN trained for 35 epochs before early stopping (best at epoch 25)
- APT28, APT29, APT19, Ajax_Security: perfect classification (F1=1.0)
- APT1/APT12 confused (shared Gh0stRAT tooling — same as Sub4 baselines)
- CNN underperforms classical baselines on this small dataset (77 samples)
- Decision Tree on 2-gram features is the best overall method

---

## Reproducibility

All results reproducible with seed=42. The training/test split is identical
to Submission 4 (same `train_test_split(stratify=y, random_state=42)`),
ensuring a controlled and fair comparison between CNN and classical baselines.
